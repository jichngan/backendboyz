#!/bin/bash

cd scripts
./main_script.sh & ./secondary_script.sh
