#!/bin/bash

cd ..
python liveplot_graph.py
