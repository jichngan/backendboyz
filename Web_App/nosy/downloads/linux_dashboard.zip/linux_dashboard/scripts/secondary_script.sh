#!/bin/bash


cd ..
python3 secondary_script.py
