#!/bin/bash

cd ..
python network_traffic.py
