#!/bin/bash

cd ..
python save_picf.py
