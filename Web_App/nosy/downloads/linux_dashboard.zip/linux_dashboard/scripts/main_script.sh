#!/bin/bash

cd ..
python main_script.py
