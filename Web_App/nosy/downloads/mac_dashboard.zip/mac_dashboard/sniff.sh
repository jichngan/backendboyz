#!/bin/bash 

cd scripts
./save_plot.sh & ./plot_script.sh & ./poison_script.sh
