#!/bin/bash

cd ..
sudo python main_script.py
