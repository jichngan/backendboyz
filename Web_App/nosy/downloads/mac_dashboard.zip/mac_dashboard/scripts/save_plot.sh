#!/bin/bash

cd ..
sudo python save_picf.py
