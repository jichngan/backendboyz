#!/bin/bash

cd ..
sudo python network_traffic.py
