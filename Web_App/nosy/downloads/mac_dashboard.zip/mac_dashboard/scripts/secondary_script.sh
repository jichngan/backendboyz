#!/bin/bash


cd ..
sudo python3 secondary_script.py
