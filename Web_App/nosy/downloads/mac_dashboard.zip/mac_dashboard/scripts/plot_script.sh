#!/bin/bash

cd ..
sudo python liveplot_graph.py
